public class Zumbi extends Monstro implements Mordida {
    private int numeroDeCerebrosComidos = 0;

    @Override
    public void atacarComMordida(Monstro monstroAlvo){
        if(this.getEnergia() >= 2){
        monstroAlvo.setVida(monstroAlvo.getVida()-3);
        this.numeroDeCerebrosComidos += 1;
        }
        else{
            System.out.println("Nao possui energia o suficiente!");
        }
    }

    public int getNumeroDeCerebrosComidos() {
        return numeroDeCerebrosComidos;
    }
}
