public class Monstro {
    private int idade;
    private int vida;
    private int energia;

    public void assustar(Monstro monstroAlvo){
        monstroAlvo.energia -= 2;
        this.energia += 2;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }
    public void setEnergia(int energia) {
        this.energia = energia;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
    public int getVida() {
        return vida;
    }
    public int getEnergia() {
        return energia;
    }
}
