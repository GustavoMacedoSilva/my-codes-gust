public class Bruxa extends Monstro{
    Feitico feiticos[] = new Feitico[5];

    Bruxa(){
        feiticos[0]= new Feitico();
        feiticos[1] = new Feitico();

        feiticos[0].setNome("Bola de Fogo");
        feiticos[0].setPoder(20);

        feiticos[1].setNome("Congelamento");
        feiticos[1].setPoder(10);
    }

    public void aprenderFeitico(Feitico feitico){
        for(int i = 0; i < feiticos.length; i++){
            if(feiticos[i] == null){
                feiticos[i] = feitico;
                System.out.println("Feitico aprendido!");
                break;
            }
        }
        System.out.println("Nao cabe mais feiticos!"); //caso a lista esteja cheia
    }

    public void listarFeiticos(){
        for(int i = 0; i < feiticos.length; i++){
            if(feiticos[i] != null){
                System.out.println("Nome do Feitico: " + feiticos[i].getNome());
                System.out.println("Poder do Feitico: " + feiticos[i].getPoder());
            }
        }
    }

    public void esquecerFeitico(int posicao){
        feiticos[posicao] = null;
    }

    public void lancarFeitico(Monstro monstroAlvo, int posicao){
        if(this.getEnergia() >= feiticos[posicao].getPoder()){
        this.setEnergia(getEnergia()-feiticos[posicao].getPoder());
        monstroAlvo.setVida(monstroAlvo.getVida() - feiticos[posicao].getPoder());
    }
    }

}
