public class Vampiro extends Monstro implements Mordida {
    private int medidorDeSangue = 0;
    private boolean formaDeMorcego = false;

    public void transformar(){
        if(formaDeMorcego){
            formaDeMorcego = false;
        }
        else{
            formaDeMorcego = true;
        }
    }

    public void recuperarVida(){
        this.setVida(this.getVida() + this.medidorDeSangue);
    }

    @Override
    public void atacarComMordida(Monstro monstroAlvo){
        if(this.getEnergia()>= 2){
        monstroAlvo.setVida(monstroAlvo.getVida()-2);
        this.medidorDeSangue += 2;
        }
        else{
            System.out.println("Nao possui energia o suficiente!");
        }
    }

    public int getMedidorDeSangue() {
        return medidorDeSangue;
    }
    
    public String getTransformacao(){
        if(this.formaDeMorcego){
            return "Esta em forma de morcego!";
        }
        else{
            return "Esta em forma de humano!";
        }
    }
}
