public class App {
    public static void main(String[] args) throws Exception {
        Monstro vamp = new Vampiro();
        Monstro zum = new Zumbi();
        Monstro bru = new Bruxa();

        vamp.setEnergia(30);
        vamp.setIdade(200);
        vamp.setVida(120);

        zum.setEnergia(50);
        zum.setIdade(55);
        zum.setVida(350);

        bru.setEnergia(60);
        bru.setIdade(70);
        bru.setVida(80);
        //feitico novo da bruxa
        Feitico feitico1 = new Feitico();
        feitico1.setNome("Raios");
        feitico1.setPoder(25);

        //acoes do vampiro
        vamp.assustar(zum);
        if(vamp instanceof Vampiro){
            Vampiro vampir = (Vampiro) vamp;
            vampir.atacarComMordida(zum);
            vampir.recuperarVida();
            vampir.transformar();
            System.out.println(vampir.getTransformacao());
        }
        System.out.println("Vida do Vampiro: " + vamp.getVida());
        System.out.println("Energia do Vampiro: " + vamp.getEnergia());
        //

        //acoes do zumbi
        zum.assustar(bru);
        if(zum instanceof Zumbi){
            Zumbi zumbi = (Zumbi) zum;
            zumbi.atacarComMordida(bru);
            System.out.println("Numero de cerebros comidos: " + zumbi.getNumeroDeCerebrosComidos());
        }
        //
        
        //acoes da bruxa
        bru.assustar(vamp);
        if(bru instanceof Bruxa){
            Bruxa bruxa = (Bruxa) bru;
            bruxa.aprenderFeitico(feitico1);
            bruxa.listarFeiticos();
            bruxa.esquecerFeitico(1);
            bruxa.listarFeiticos();
            bruxa.lancarFeitico(vamp, 2);
        }

        System.out.println("Vida do Vampiro: " + vamp.getVida());
        System.out.println("Vida do Zumbi: "+ zum.getVida());
        System.out.println("Vida da Bruxa: " + bru.getVida());

        //caso nao tenha energia suficiente
        vamp.setEnergia(1);
        if(vamp instanceof Vampiro){
            Vampiro vampiro = (Vampiro) vamp;
            vampiro.atacarComMordida(vampiro);
        }
    }
}
