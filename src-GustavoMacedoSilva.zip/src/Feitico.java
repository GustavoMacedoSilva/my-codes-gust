public class Feitico{
    private String nome;
    private int poder;

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setPoder(int poder) {
        this.poder = poder;
    }
    public String getNome() {
        return nome;
    }
    public int getPoder() {
        return poder;
    }
}