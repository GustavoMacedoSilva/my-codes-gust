public interface Mordida {
    public void atacarComMordida(Monstro monstroAlvo);
}
